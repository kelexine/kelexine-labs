# kl-notes Documentation

## Overview
A simple command-line note-taking utility for Termux.

## Usage
```bash
kl-notes --help
```

## Support
For support, please contact: Kelexine Labs <kelexine@gmail.com>
